package Part_A;

public interface IType {
	public void m2(String s);
	public void m3();

}
