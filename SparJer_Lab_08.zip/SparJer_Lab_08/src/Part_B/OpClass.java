package Part_B;

public interface OpClass {
	abstract Object op(Object arg);
}
